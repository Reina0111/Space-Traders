start gry w pliku "index.html"
